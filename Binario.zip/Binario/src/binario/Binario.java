
package binario;

import java.util.Scanner;
public class Binario {
  public static void main(String[] args) {
    long num, aux, digito, NumReal;
     int exponente;
     int i = 0;
     boolean checar;
     boolean camar;
     String resp;
     Scanner sc = new Scanner(System.in);
      System.out.println("¿Que desea hacer?");
      System.out.println("A---> Binario a decimal");
      System.out.println("B---> Decimal a binario");
      resp = sc.nextLine();
      if ("A".equals(resp)){
     do 
     {
          System.out.println("Ponga número que desee convertir: ");
          num = sc.nextLong();
          checar = true;
          aux = num;
          while (aux != 0) 
          {
                     digito = aux % 10;
                     if (digito != 0 && digito != 1) 
                     { 
                     i++; 
                     checar = false;
                     System.out.println("Existen digitos que no son binarios (0 || 1)");     
                     }  
                     aux = aux / 10; 
           }
      } 
     while (!checar);

      exponente = 0;
      NumReal = 0; 
      while (num != 0)
      {
                digito = num % 10;
                NumReal = NumReal + digito * (int) Math.pow(2, exponente);               
                exponente++;
                num = num / 10;
      }
      System.out.println("Núm decimal--> " + NumReal);
   }
      if ("B".equals(resp))
  {
    System.out.println("Ingresa un número");
            float Numero = sc.nextFloat();
            String Cadena = "";
            String Cadena1 = "";
                while(Numero>0){
                    if(Numero%2==0){
                        Cadena=Cadena+"0";
                    }else{
                        Cadena=Cadena+"1";
                    }
                    Numero=(int)Numero/2;
                }
                for (int j=Cadena.length()-1;j>=0;j--)
                {
                   	Cadena1 = Cadena1 + Cadena.charAt(j);
                }
                System.out.println("El número convertido a binario es: "+Cadena1);
        }  
      else{
          System.out.println("Ingrese una opción valida");
      }
      }
      
  }
    